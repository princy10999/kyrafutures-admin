import React from "react";
import {Builder} from "../../_metronic/_partials";

export function BuilderPage() {
    return <Builder />;
}
