import React, { useState } from "react";
import { Link, useHistory } from "react-router-dom";
import { ErrorMessage, Field, Form, Formik } from "formik";
import * as Yup from "yup";
import { connect, useDispatch } from "react-redux";
import { injectIntl } from "react-intl";
import * as auth from "../_redux/authRedux";
import { login } from "../../../../Redux/Actions/AuthUser";
import "react-phone-number-input/style.css";
import IntlTelInput from "react-bootstrap-intl-tel-input";
import { Box, Grid, TextField } from "@material-ui/core";
import { ErrorToast, SuccessToast } from "../../../../helpers/Toast";

function Login(props) {
  const { intl } = props;
  const history = useHistory();
  const [loading, setLoading] = useState(false);

  const [value, setValue] = useState();

  const dispatch = useDispatch();

  const onChangeHandler = (data) => {
    setValue(data);
  };

  console.log("value", value);

  const [initialValues, setInitialValues] = React.useState({
    password: "",
  });

  const validationSchema = Yup.object().shape({
    password: Yup.string()
      .trim()
      .required("Please enter your password!"),
  });

  const onSubmit = async (values) => {
    const body = {
      phoneNumberCode: value?.countryCallingCodes[0],
      phoneNumber: value?.phoneNumber.replace(/ /g, ""),
      password: values?.password,
    };

    if (body?.phoneNumber === "") {
      ErrorToast("Please enter phone number!");
    } else if (body?.phoneNumberCode === undefined) {
      ErrorToast("Please enter phone number code!");
    } else {
      const getData = await dispatch(login(body));
      SuccessToast(getData?.payload?.message);
      localStorage.setItem(
        "userinfo",
        JSON.stringify(getData?.payload?.result)
      );
      localStorage.setItem(
        "token",
        JSON.stringify(getData?.payload?.result?.tokenInfo)
      );
      localStorage.setItem(
        "access_token",
        getData?.payload?.result?.tokenInfo?.token
      );
      window.location.pathname = "/dashboard";
      // window.location.pathname = "/dashboard";
      console.log("getData", getData);
    }
  };
  return (
    <Formik
      enableReinitialize={true}
      initialValues={initialValues}
      validationSchema={validationSchema}
      onSubmit={onSubmit}
    >
      {({ values, setFieldValue }) => (
        <Form>
          <Grid container spacing={2}>
            <Grid item lg={12} md={12} sm={12} className="phone-number">
              <IntlTelInput
                preferredCountries={["IN"]}
                defaultCountry={"IN"}
                defaultValue={""}
                onChange={(data) => onChangeHandler(data)}
              />
            </Grid>
            <Grid item lg={12} md={12} sm={12}>
              <Field
                fullWidth
                as={TextField}
                label="Password"
                name="password"
                variant="outlined"
                helperText={
                  <Box component="span" disableGutters className="text-danger">
                    <ErrorMessage name="password" />
                  </Box>
                }
              />
            </Grid>
          </Grid>
          <div className="form-group d-flex flex-wrap justify-content-center align-items-center">
            <button
              id="kt_login_signin_submit"
              type="submit"
              className={`btn font-weight-bold px-9 py-4 my-3 text-white`}
              style={{
                background:
                  "  linear-gradient(88.72deg, #3AB5F4 0%, #814EB7 100%)",
              }}
            >
              <span>Sign In</span>
              {loading && <span className="ml-3 spinner spinner-white"></span>}
            </button>
          </div>
        </Form>
      )}
    </Formik>
  );
}

export default injectIntl(connect(null, auth.actions)(Login));
