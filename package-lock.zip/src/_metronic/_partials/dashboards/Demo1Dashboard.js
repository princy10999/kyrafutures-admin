import React from "react";
import { useHistory } from "react-router-dom";

export function Demo1Dashboard() {
  const history = useHistory();
  return (
    <>
      <div className="row">
        <div className="col-lg-12 col-xxl-12">
          {/* <MixedWidget1 className="card-stretch gutter-b" /> */}
        </div>
      </div>
    </>
  );
}
